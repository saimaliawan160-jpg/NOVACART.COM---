import { Product, Category, Review } from './types';

const reviewBank: { author: string; comment: string }[] = [
  { author: 'Ayesha K.', comment: 'Quality is much better than I expected for the price. Arrived well packed.' },
  { author: 'Bilal R.', comment: 'Exactly as shown in the photos. Fast delivery, will order again.' },
  { author: 'Sana M.', comment: 'Good value for money, works perfectly. Minor delay in shipping but worth the wait.' },
  { author: 'Usman T.', comment: 'Bought this as a gift and they loved it. Packaging felt premium too.' },
  { author: 'Hira A.', comment: 'Not bad, does the job. Could be slightly better quality but happy overall.' },
  { author: 'Fahad N.', comment: 'Five stars, this is my second order from this category and both were great.' },
  { author: 'Mehwish S.', comment: 'Customer service replied quickly when I asked about sizing. Very satisfied.' },
  { author: 'Zain U.', comment: 'Looks even better in person. Sturdy build quality.' },
  { author: 'Ramsha I.', comment: 'Decent product, matches the description. Would recommend to friends.' },
  { author: 'Omar F.', comment: 'Took about a week to arrive but the product itself is solid.' },
];

function makeReviews(seed: number, count: number): Review[] {
  const out: Review[] = [];
  for (let i = 0; i < count; i++) {
    const pick = reviewBank[(seed + i) % reviewBank.length];
    const rating = [5, 5, 4, 5, 4, 3, 5][(seed + i) % 7];
    out.push({
      id: `rev-${seed}-${i}`,
      author: pick.author,
      rating,
      comment: pick.comment,
      date: `2026-0${((seed + i) % 6) + 1}-${10 + ((seed + i) % 18)}`,
    });
  }
  return out;
}

interface Template {
  name: string;
  price: number;
  compareAtPrice?: number;
  description: string;
  seedImg: string;
}

const catalog: Record<Category, Template[]> = {
  'Smart Gadgets': [
    { name: 'Wireless Earbuds Pro', price: 3499, compareAtPrice: 4999, description: 'Bluetooth 5.3 earbuds with active noise cancellation, 30-hour battery life, and touch controls.', seedImg: 'gadget1' },
    { name: 'Smart Fitness Band X2', price: 2899, compareAtPrice: 3999, description: 'Tracks heart rate, sleep, and steps with a vivid color display and 7-day battery.', seedImg: 'gadget2' },
    { name: 'Portable Mini Projector', price: 8999, description: 'Compact HD projector for movie nights, supports HDMI and USB, built-in speaker.', seedImg: 'gadget3' },
    { name: 'Magnetic Wireless Power Bank', price: 3299, description: '10000mAh power bank with magnetic fast charging, fits in any pocket.', seedImg: 'gadget4' },
    { name: 'Smart LED Desk Lamp', price: 2499, description: 'Touch-control desk lamp with adjustable brightness and wireless charging base.', seedImg: 'gadget5' },
    { name: 'Bluetooth Tracker Tag (2-Pack)', price: 1999, description: 'Never lose your keys or bag again, pairs with your phone for real-time location.', seedImg: 'gadget6' },
    { name: 'Mini Bluetooth Speaker', price: 2199, compareAtPrice: 2899, description: 'Pocket-size speaker with surprisingly big sound and 12-hour playtime.', seedImg: 'gadget7' },
    { name: 'Smart Plug Wi-Fi Outlet (2-Pack)', price: 1799, description: 'Control lights and appliances from your phone, works with voice assistants.', seedImg: 'gadget8' },
    { name: 'Phone Camera Lens Kit', price: 2599, description: 'Clip-on wide angle, macro, and fisheye lenses for next-level mobile photography.', seedImg: 'gadget9' },
    { name: 'Smart Ring Air Mouse Remote', price: 1499, description: 'Gesture-control air mouse for presentations, smart TVs, and gaming.', seedImg: 'gadget10' },
  ],
  'Fashion Accessories': [
    { name: 'Minimalist Leather Wallet', price: 1899, description: 'Slim genuine-look leather wallet with RFID-blocking card slots.', seedImg: 'fash1' },
    { name: 'Classic Aviator Sunglasses', price: 1599, compareAtPrice: 2299, description: 'UV400 protection with a timeless metal frame, unisex design.', seedImg: 'fash2' },
    { name: 'Stainless Steel Chain Bracelet', price: 1299, description: 'Adjustable unisex bracelet, tarnish-resistant and water safe.', seedImg: 'fash3' },
    { name: 'Layered Pendant Necklace Set', price: 1699, description: 'Three-piece layered necklace set, gold-tone finish, hypoallergenic.', seedImg: 'fash4' },
    { name: 'Canvas Crossbody Sling Bag', price: 2299, description: 'Lightweight everyday sling bag with multiple compartments.', seedImg: 'fash5' },
    { name: 'Classic Analog Wrist Watch', price: 3499, compareAtPrice: 4599, description: 'Minimalist dial with leather strap, water resistant up to 30m.', seedImg: 'fash6' },
    { name: 'Embroidered Silk Scarf', price: 1399, description: 'Soft, breathable scarf with hand-finished edges, multiple ways to style.', seedImg: 'fash7' },
    { name: 'Polarized Cat-Eye Sunglasses', price: 1799, description: 'Trendy cat-eye frame with polarized lenses for everyday glare protection.', seedImg: 'fash8' },
    { name: 'Beaded Statement Earrings', price: 999, description: 'Lightweight beaded drop earrings, hypoallergenic posts.', seedImg: 'fash9' },
  ],
  'Beauty Products': [
    { name: 'Vitamin C Brightening Serum', price: 1999, compareAtPrice: 2799, description: '20% Vitamin C serum for brighter, even-toned skin, suitable for all skin types.', seedImg: 'beauty1' },
    { name: 'Hyaluronic Acid Moisturizer', price: 1799, description: 'Lightweight gel moisturizer that locks in hydration for 24 hours.', seedImg: 'beauty2' },
    { name: 'Matte Liquid Lipstick Set (6pc)', price: 1599, description: 'Long-lasting, transfer-resistant matte lipsticks in everyday shades.', seedImg: 'beauty3' },
    { name: 'Rose Quartz Facial Roller', price: 1199, description: 'Cooling facial roller to reduce puffiness and improve circulation.', seedImg: 'beauty4' },
    { name: 'LED Makeup Mirror with Lights', price: 2899, compareAtPrice: 3499, description: 'Tri-fold mirror with adjustable LED lighting and USB charging.', seedImg: 'beauty5' },
    { name: 'Charcoal Detox Face Mask', price: 999, description: 'Deep-cleansing peel-off mask that draws out impurities and blackheads.', seedImg: 'beauty6' },
    { name: 'Professional Hair Straightener Brush', price: 2499, description: 'Ceramic heating brush that straightens while you style, anti-scald design.', seedImg: 'beauty7' },
    { name: 'Eyebrow & Eyeliner Stamp Kit', price: 1399, description: 'One-step stamp kit for perfectly shaped, symmetrical brows in seconds.', seedImg: 'beauty8' },
  ],
  'Kitchen Items': [
    { name: 'Stainless Steel Knife Set (5pc)', price: 3299, compareAtPrice: 4299, description: 'Precision-forged knives with ergonomic handles, includes acrylic stand.', seedImg: 'kitchen1' },
    { name: 'Electric Vegetable Chopper', price: 2199, description: 'One-touch chopper for onions, garlic, and veggies, easy to clean.', seedImg: 'kitchen2' },
    { name: 'Silicone Baking Mat Set (3pc)', price: 1299, description: 'Non-stick reusable baking mats, oven and microwave safe.', seedImg: 'kitchen3' },
    { name: 'Glass Meal Prep Containers (5pc)', price: 2599, description: 'Leak-proof, microwave-safe containers with snap lids for meal planning.', seedImg: 'kitchen4' },
    { name: 'Multi-Function Spiralizer', price: 1799, description: 'Turn vegetables into noodles and ribbons in seconds, dishwasher safe.', seedImg: 'kitchen5' },
    { name: 'Stovetop Espresso Maker', price: 2899, description: 'Classic Italian-style moka pot for rich, authentic espresso at home.', seedImg: 'kitchen6' },
    { name: 'Adjustable Rolling Pin with Rings', price: 1099, description: 'Silicone rolling pin with removable thickness rings for perfect dough.', seedImg: 'kitchen7' },
    { name: 'Electric Milk Frother Wand', price: 1499, description: 'Rechargeable frother for café-style lattes and cappuccinos at home.', seedImg: 'kitchen8' },
  ],
  'Home Decor': [
    { name: 'Macrame Wall Hanging', price: 1899, description: 'Handwoven cotton macrame for a cozy boho accent wall.', seedImg: 'decor1' },
    { name: 'Set of 3 Geometric Wall Shelves', price: 2799, compareAtPrice: 3599, description: 'Floating shelves for plants, books, and decor, easy wall mount.', seedImg: 'decor2' },
    { name: 'LED Strip Lights with Remote (5m)', price: 1599, description: 'Color-changing ambient lighting for bedrooms, gaming setups, and parties.', seedImg: 'decor3' },
    { name: 'Ceramic Vase Trio Set', price: 2299, description: 'Minimalist ceramic vases in three sizes, perfect for dried or fresh flowers.', seedImg: 'decor4' },
    { name: 'Soft Textured Throw Pillow Covers (2pc)', price: 1199, description: 'Cozy linen-look covers to instantly refresh any sofa or bed.', seedImg: 'decor5' },
    { name: 'Wooden Floating Photo Frame Shelf', price: 1699, description: 'Display photos and small decor pieces without nails or drilling.', seedImg: 'decor6' },
    { name: 'Aromatherapy Essential Oil Diffuser', price: 2399, compareAtPrice: 2999, description: 'Whisper-quiet ultrasonic diffuser with 7-color ambient lighting.', seedImg: 'decor7' },
    { name: 'Artificial Eucalyptus Garland (2m)', price: 999, description: 'Realistic faux greenery for shelves, mantels, and table runners.', seedImg: 'decor8' },
  ],
  'Trending Products': [
    { name: 'Posture Corrector Back Brace', price: 1899, description: 'Adjustable brace to support shoulders and spine for better posture.', seedImg: 'trend1' },
    { name: 'Mini Handheld Neck Fan', price: 1399, compareAtPrice: 1899, description: 'Hands-free wearable fan with 3 speed settings, rechargeable battery.', seedImg: 'trend2' },
    { name: 'Self-Stirring Mug', price: 999, description: 'Battery-powered mug that mixes your coffee or protein shake automatically.', seedImg: 'trend3' },
    { name: 'Car Phone Holder with Wireless Charging', price: 2199, description: 'Auto-clamping mount with fast wireless charging for any dashboard.', seedImg: 'trend4' },
    { name: 'Resistance Bands Set (5pc)', price: 1499, description: 'Full home workout set with varying resistance levels and carry bag.', seedImg: 'trend5' },
    { name: 'Acupressure Mat & Pillow Set', price: 1799, description: 'Relieves tension and improves circulation, used daily for 10-20 minutes.', seedImg: 'trend6' },
    { name: 'Portable Blender Bottle', price: 1999, compareAtPrice: 2599, description: 'USB-rechargeable blender for smoothies and shakes on the go.', seedImg: 'trend7' },
    { name: 'Foldable Laptop Stand', price: 1599, description: 'Aluminum stand for ergonomic typing and better laptop cooling.', seedImg: 'trend8' },
    { name: 'Reusable Silicone Food Bags (4pc)', price: 1299, description: 'Leak-proof, freezer and microwave safe bags to cut down on plastic waste.', seedImg: 'trend9' },
    { name: 'Smart Water Bottle with Time Markers', price: 1099, compareAtPrice: 1499, description: 'Motivational time markings to help you hit your daily water intake goal.', seedImg: 'trend10' },
  ],
};

function buildProducts(): Product[] {
  const products: Product[] = [];
  let seed = 1;
  (Object.keys(catalog) as Category[]).forEach((category) => {
    catalog[category].forEach((t) => {
      const id = `p${seed}`;
      const reviewCount = 8 + (seed % 40);
      const reviews = makeReviews(seed, 3);
      const avgRating = Math.round((reviews.reduce((a, r) => a + r.rating, 0) / reviews.length) * 10) / 10;
      products.push({
        id,
        name: t.name,
        category,
        price: t.price,
        compareAtPrice: t.compareAtPrice,
        description: t.description,
        images: [
          `https://picsum.photos/seed/${t.seedImg}a/700/700`,
          `https://picsum.photos/seed/${t.seedImg}b/700/700`,
          `https://picsum.photos/seed/${t.seedImg}c/700/700`,
        ],
        rating: avgRating,
        reviewCount,
        reviews,
        stock: 15 + (seed % 30),
        trending: category === 'Trending Products' || seed % 7 === 0,
      });
      seed++;
    });
  });
  return products;
}

export const PRODUCTS: Product[] = buildProducts();

export const CATEGORIES: Category[] = [
  'Smart Gadgets',
  'Fashion Accessories',
  'Beauty Products',
  'Kitchen Items',
  'Home Decor',
  'Trending Products',
];

export function getProductById(id: string): Product | undefined {
  return PRODUCTS.find((p) => p.id === id);
}

export function getProductsByCategory(category: Category): Product[] {
  return PRODUCTS.filter((p) => p.category === category);
}

export function getTrendingProducts(): Product[] {
  return PRODUCTS.filter((p) => p.trending).slice(0, 8);
}

export function searchProducts(query: string): Product[] {
  const q = query.toLowerCase();
  return PRODUCTS.filter(
    (p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
  );
}
