// Firebase integration — OPTIONAL UPGRADE PATH
//
// Velmora works out of the box using localStorage (see lib/store.ts), so you can
// run and demo the whole site with zero setup. When you're ready to go to
// production with real persistence across devices, follow these steps:
//
// 1. Create a project at https://console.firebase.google.com
// 2. Enable: Authentication (Email/Password), Firestore Database, Storage
// 3. Copy your config values into .env.local (see .env.local.example)
// 4. Replace the calls in lib/store.ts with the functions exported below
//
// This file is safe to import even without env vars set — it simply won't
// initialize until real config values are present.

import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  Firestore,
} from 'firebase/firestore';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  Auth,
} from 'firebase/auth';
import { getStorage, ref, uploadBytes, getDownloadURL, FirebaseStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

const isConfigured = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;
let storage: FirebaseStorage | null = null;

if (isConfigured) {
  app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
  db = getFirestore(app);
  auth = getAuth(app);
  storage = getStorage(app);
}

export { app, db, auth, storage, isConfigured };

/* ---------------- Firestore: Products ---------------- */

export async function fsGetProducts() {
  if (!db) throw new Error('Firebase is not configured yet.');
  const snap = await getDocs(collection(db, 'products'));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function fsAddProduct(data: any) {
  if (!db) throw new Error('Firebase is not configured yet.');
  return addDoc(collection(db, 'products'), data);
}

export async function fsUpdateProduct(id: string, data: any) {
  if (!db) throw new Error('Firebase is not configured yet.');
  return updateDoc(doc(db, 'products', id), data);
}

export async function fsDeleteProduct(id: string) {
  if (!db) throw new Error('Firebase is not configured yet.');
  return deleteDoc(doc(db, 'products', id));
}

/* ---------------- Firestore: Orders ---------------- */

export async function fsCreateOrder(order: any) {
  if (!db) throw new Error('Firebase is not configured yet.');
  return addDoc(collection(db, 'orders'), order);
}

export async function fsGetOrders() {
  if (!db) throw new Error('Firebase is not configured yet.');
  const snap = await getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function fsUpdateOrderStatus(id: string, status: string) {
  if (!db) throw new Error('Firebase is not configured yet.');
  return updateDoc(doc(db, 'orders', id), { status });
}

/* ---------------- Firestore: Reviews ---------------- */

export async function fsAddReview(productId: string, review: any) {
  if (!db) throw new Error('Firebase is not configured yet.');
  return addDoc(collection(db, 'products', productId, 'reviews'), review);
}

export async function fsGetReviews(productId: string) {
  if (!db) throw new Error('Firebase is not configured yet.');
  const snap = await getDocs(collection(db, 'products', productId, 'reviews'));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

/* ---------------- Auth ---------------- */

export async function authSignUp(email: string, password: string) {
  if (!auth) throw new Error('Firebase is not configured yet.');
  return createUserWithEmailAndPassword(auth, email, password);
}

export async function authSignIn(email: string, password: string) {
  if (!auth) throw new Error('Firebase is not configured yet.');
  return signInWithEmailAndPassword(auth, email, password);
}

export async function authSignOut() {
  if (!auth) throw new Error('Firebase is not configured yet.');
  return signOut(auth);
}

export async function authResetPassword(email: string) {
  if (!auth) throw new Error('Firebase is not configured yet.');
  return sendPasswordResetEmail(auth, email);
}

/* ---------------- Storage: product images ---------------- */

export async function storageUploadImage(file: File, path: string): Promise<string> {
  if (!storage) throw new Error('Firebase is not configured yet.');
  const fileRef = ref(storage, path);
  await uploadBytes(fileRef, file);
  return getDownloadURL(fileRef);
}
