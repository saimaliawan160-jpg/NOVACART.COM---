'use client';

import { CartItem, Order, OrderStatus, Review } from './types';

const CART_KEY = 'velmora_cart';
const ORDERS_KEY = 'velmora_orders';
const USERS_KEY = 'velmora_users';
const SESSION_KEY = 'velmora_session';
const REVIEWS_KEY = 'velmora_user_reviews';
const ADMIN_SESSION_KEY = 'velmora_admin_session';

function read<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

/* ---------------- Cart ---------------- */

export function getCart(): CartItem[] {
  return read<CartItem[]>(CART_KEY, []);
}

export function saveCart(items: CartItem[]) {
  write(CART_KEY, items);
}

export function addToCart(item: CartItem) {
  const cart = getCart();
  const existing = cart.find((c) => c.productId === item.productId);
  if (existing) {
    existing.quantity += item.quantity;
  } else {
    cart.push(item);
  }
  saveCart(cart);
  return cart;
}

export function updateCartQuantity(productId: string, quantity: number) {
  let cart = getCart();
  if (quantity <= 0) {
    cart = cart.filter((c) => c.productId !== productId);
  } else {
    cart = cart.map((c) => (c.productId === productId ? { ...c, quantity } : c));
  }
  saveCart(cart);
  return cart;
}

export function removeFromCart(productId: string) {
  const cart = getCart().filter((c) => c.productId !== productId);
  saveCart(cart);
  return cart;
}

export function clearCart() {
  saveCart([]);
}

export function cartTotal(cart: CartItem[]) {
  return cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
}

/* ---------------- Orders ---------------- */

export function getOrders(): Order[] {
  return read<Order[]>(ORDERS_KEY, []);
}

export function saveOrder(order: Order) {
  const orders = getOrders();
  orders.unshift(order);
  write(ORDERS_KEY, orders);
}

export function getOrderById(id: string): Order | undefined {
  return getOrders().find((o) => o.id === id);
}

export function updateOrderStatus(id: string, status: OrderStatus) {
  const orders = getOrders().map((o) => (o.id === id ? { ...o, status } : o));
  write(ORDERS_KEY, orders);
  return orders;
}

export function generateOrderId() {
  return 'VLM' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

/* ---------------- Users (simple demo auth, swap for Firebase Auth later) ---------------- */

interface StoredUser {
  name: string;
  email: string;
  password: string;
}

export function signUp(name: string, email: string, password: string): { ok: boolean; error?: string } {
  const users = read<StoredUser[]>(USERS_KEY, []);
  if (users.find((u) => u.email === email)) {
    return { ok: false, error: 'An account with this email already exists.' };
  }
  users.push({ name, email, password });
  write(USERS_KEY, users);
  write(SESSION_KEY, { name, email });
  return { ok: true };
}

export function signIn(email: string, password: string): { ok: boolean; error?: string } {
  const users = read<StoredUser[]>(USERS_KEY, []);
  const user = users.find((u) => u.email === email && u.password === password);
  if (!user) return { ok: false, error: 'Incorrect email or password.' };
  write(SESSION_KEY, { name: user.name, email: user.email });
  return { ok: true };
}

export function signOutUser() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(SESSION_KEY);
}

export function getSession(): { name: string; email: string } | null {
  return read(SESSION_KEY, null as any);
}

export function resetPassword(email: string): { ok: boolean; error?: string } {
  const users = read<StoredUser[]>(USERS_KEY, []);
  if (!users.find((u) => u.email === email)) {
    return { ok: false, error: 'No account found with that email.' };
  }
  // In production this triggers Firebase's sendPasswordResetEmail() instead.
  return { ok: true };
}

/* ---------------- Admin session ---------------- */

const ADMIN_PASSWORD = 'admin123'; // change this before going live

export function adminSignIn(password: string): boolean {
  if (password === ADMIN_PASSWORD) {
    write(ADMIN_SESSION_KEY, true);
    return true;
  }
  return false;
}

export function isAdmin(): boolean {
  return read(ADMIN_SESSION_KEY, false);
}

export function adminSignOut() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(ADMIN_SESSION_KEY);
}

/* ---------------- Reviews submitted by customers ---------------- */

export function getUserReviews(): Record<string, Review[]> {
  return read<Record<string, Review[]>>(REVIEWS_KEY, {});
}

export function addUserReview(productId: string, review: Review) {
  const all = getUserReviews();
  if (!all[productId]) all[productId] = [];
  all[productId].push(review);
  write(REVIEWS_KEY, all);
  return all[productId];
}

/* ---------------- Custom/admin-added products (merged with the seed catalog) ---------------- */

const CUSTOM_PRODUCTS_KEY = 'velmora_custom_products';

export function getCustomProducts<T>(): T[] {
  return read<T[]>(CUSTOM_PRODUCTS_KEY, []);
}

export function saveCustomProducts<T>(products: T[]) {
  write(CUSTOM_PRODUCTS_KEY, products);
}
