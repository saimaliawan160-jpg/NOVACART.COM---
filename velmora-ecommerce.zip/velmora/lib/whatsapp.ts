import { CartItem } from './types';

export function getWhatsAppNumber(): string {
  return process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '923374849767';
}

interface OrderMessageInput {
  orderId: string;
  customerName: string;
  phone: string;
  address: string;
  city: string;
  paymentMethod: string;
  items: CartItem[];
  total: number;
}

export function buildOrderMessage(input: OrderMessageInput): string {
  const productLines = input.items
    .map((i) => `  • ${i.name} x${i.quantity} — Rs. ${(i.price * i.quantity).toLocaleString()}`)
    .join('\n');

  return [
    '🛍️ *New Order Received*',
    '',
    `*Order ID:* ${input.orderId}`,
    `*Name:* ${input.customerName}`,
    `*Phone:* ${input.phone}`,
    `*Address:* ${input.address}, ${input.city}`,
    `*Payment Method:* ${input.paymentMethod}`,
    '',
    '*Products:*',
    productLines,
    '',
    `*Total:* Rs. ${input.total.toLocaleString()}`,
    `*Status:* Pending`,
  ].join('\n');
}

export function buildWhatsAppLink(message: string): string {
  const number = getWhatsAppNumber();
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}
