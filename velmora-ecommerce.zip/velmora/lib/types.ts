export type Category =
  | 'Smart Gadgets'
  | 'Fashion Accessories'
  | 'Beauty Products'
  | 'Kitchen Items'
  | 'Home Decor'
  | 'Trending Products';

export interface Review {
  id: string;
  author: string;
  rating: number; // 1-5
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  category: Category;
  price: number;
  compareAtPrice?: number;
  description: string;
  images: string[];
  rating: number;
  reviewCount: number;
  reviews: Review[];
  stock: number;
  trending?: boolean;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

export type OrderStatus = 'Pending' | 'Processing' | 'Shipped' | 'Delivered';

export interface Order {
  id: string;
  customerName: string;
  phone: string;
  address: string;
  city: string;
  paymentMethod: 'COD' | 'Easypaisa' | 'JazzCash' | 'Bank Transfer';
  items: CartItem[];
  total: number;
  status: OrderStatus;
  createdAt: string;
}
