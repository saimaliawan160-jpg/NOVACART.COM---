import Hero from '@/components/Hero';
import CategoryGrid from '@/components/CategoryGrid';
import ProductCard from '@/components/ProductCard';
import { PRODUCTS, getTrendingProducts } from '@/lib/products';
import Link from 'next/link';

export default function HomePage() {
  const trending = getTrendingProducts();
  const featured = PRODUCTS.slice(0, 8);

  return (
    <>
      <Hero />
      <CategoryGrid />

      <section className="section-pad py-10">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold text-ink">Trending Now 🔥</h2>
          <Link href="/products?category=Trending%20Products" className="text-sm font-semibold text-brand-600 hover:underline">
            View all
          </Link>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {trending.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="section-pad py-10">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold text-ink">Featured Products</h2>
          <Link href="/products" className="text-sm font-semibold text-brand-600 hover:underline">
            View all
          </Link>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {featured.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="section-pad py-14">
        <div className="grid gap-6 rounded-2xl bg-gradient-to-br from-ink to-ocean-900 p-10 text-white sm:grid-cols-3">
          <div>
            <p className="text-2xl">🚚</p>
            <h3 className="mt-2 font-display font-semibold">Fast Delivery</h3>
            <p className="mt-1 text-sm text-white/60">2–5 day delivery across Pakistan.</p>
          </div>
          <div>
            <p className="text-2xl">💵</p>
            <h3 className="mt-2 font-display font-semibold">Cash on Delivery</h3>
            <p className="mt-1 text-sm text-white/60">Pay when your order arrives at your door.</p>
          </div>
          <div>
            <p className="text-2xl">⭐</p>
            <h3 className="mt-2 font-display font-semibold">Quality Checked</h3>
            <p className="mt-1 text-sm text-white/60">Every product is reviewed before it's listed.</p>
          </div>
        </div>
      </section>
    </>
  );
}
