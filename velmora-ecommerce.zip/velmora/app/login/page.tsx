'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import * as store from '@/lib/store';
import { useAuth } from '@/context/AuthContext';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();
  const { refresh } = useAuth();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const result = store.signIn(email, password);
    if (!result.ok) {
      setError(result.error || 'Login failed.');
      return;
    }
    refresh();
    router.push('/');
  }

  return (
    <div className="section-pad flex min-h-[70vh] items-center justify-center py-10">
      <div className="w-full max-w-sm rounded-2xl border border-ink/5 bg-white p-8 shadow-card">
        <h1 className="font-display text-2xl font-bold text-ink">Welcome back</h1>
        <p className="mt-1 text-sm text-ink/50">Log in to track orders and save your details.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="input-field" />
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="input-field" />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button type="submit" className="btn-primary w-full">Log In</button>
        </form>

        <div className="mt-4 flex justify-between text-sm">
          <Link href="/forgot-password" className="text-brand-600 hover:underline">Forgot password?</Link>
          <Link href="/signup" className="text-brand-600 hover:underline">Create account</Link>
        </div>
      </div>
    </div>
  );
}
