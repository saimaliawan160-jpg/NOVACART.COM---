import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="section-pad flex min-h-[60vh] flex-col items-center justify-center text-center py-20">
      <p className="text-5xl">🔍</p>
      <h1 className="mt-4 font-display text-2xl font-bold text-ink">Page not found</h1>
      <p className="mt-2 text-sm text-ink/50">The page you're looking for doesn't exist or has moved.</p>
      <Link href="/" className="btn-primary mt-6 inline-block">Back to Home</Link>
    </div>
  );
}
