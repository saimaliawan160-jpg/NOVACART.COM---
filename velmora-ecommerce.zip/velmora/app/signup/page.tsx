'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import * as store from '@/lib/store';
import { useAuth } from '@/context/AuthContext';

export default function SignupPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();
  const { refresh } = useAuth();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    const result = store.signUp(name, email, password);
    if (!result.ok) {
      setError(result.error || 'Could not create account.');
      return;
    }
    refresh();
    router.push('/');
  }

  return (
    <div className="section-pad flex min-h-[70vh] items-center justify-center py-10">
      <div className="w-full max-w-sm rounded-2xl border border-ink/5 bg-white p-8 shadow-card">
        <h1 className="font-display text-2xl font-bold text-ink">Create your account</h1>
        <p className="mt-1 text-sm text-ink/50">Faster checkout and order tracking.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" className="input-field" />
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="input-field" />
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="input-field" />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button type="submit" className="btn-primary w-full">Sign Up</button>
        </form>

        <p className="mt-4 text-center text-sm text-ink/50">
          Already have an account? <Link href="/login" className="text-brand-600 hover:underline">Log in</Link>
        </p>
      </div>
    </div>
  );
}
