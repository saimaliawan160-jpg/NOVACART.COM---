import { Suspense } from 'react';
import TrackOrderContent from './TrackOrderContent';

export const metadata = {
  title: 'Track Your Order',
  description: 'Track your Velmora order status using your order ID.',
};

export default function TrackOrderPage() {
  return (
    <Suspense fallback={<div className="section-pad py-20 text-center text-ink/40">Loading...</div>}>
      <TrackOrderContent />
    </Suspense>
  );
}
