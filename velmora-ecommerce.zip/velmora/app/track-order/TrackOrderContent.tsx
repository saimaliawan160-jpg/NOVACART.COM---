'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import * as store from '@/lib/store';
import { Order, OrderStatus } from '@/lib/types';

const STEPS: OrderStatus[] = ['Pending', 'Processing', 'Shipped', 'Delivered'];

export default function TrackOrderContent() {
  const searchParams = useSearchParams();
  const justPlaced = searchParams.get('placed') === '1';

  const [orderId, setOrderId] = useState(searchParams.get('id') || '');
  const [order, setOrder] = useState<Order | null>(null);
  const [searched, setSearched] = useState(false);

  function handleSearch(e?: React.FormEvent) {
    e?.preventDefault();
    setSearched(true);
    setOrder(store.getOrderById(orderId.trim()) || null);
  }

  useEffect(() => {
    if (searchParams.get('id')) handleSearch();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const activeStep = order ? STEPS.indexOf(order.status) : -1;

  return (
    <div className="section-pad py-10">
      <h1 className="font-display text-3xl font-bold text-ink">Track Your Order</h1>

      {justPlaced && (
        <div className="mt-4 rounded-xl bg-brand-50 px-4 py-3 text-sm font-medium text-brand-700">
          🎉 Order placed! We opened WhatsApp with your order details — please hit send so our team can confirm it.
        </div>
      )}

      <form onSubmit={handleSearch} className="mt-6 flex max-w-md gap-3">
        <input
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          placeholder="Enter your Order ID (e.g. VLM4F2A1B)"
          className="input-field"
        />
        <button type="submit" className="btn-primary">Track</button>
      </form>

      {searched && !order && (
        <p className="mt-6 text-sm text-red-600">No order found with that ID. Double-check and try again.</p>
      )}

      {order && (
        <div className="mt-8 max-w-2xl rounded-2xl border border-ink/5 bg-white p-6 shadow-card">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-xs text-ink/40">Order ID</p>
              <p className="font-display font-bold text-ink">{order.id}</p>
            </div>
            <div>
              <p className="text-xs text-ink/40">Placed on</p>
              <p className="font-medium text-ink">{new Date(order.createdAt).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-xs text-ink/40">Total</p>
              <p className="font-medium text-ink">Rs. {order.total.toLocaleString()}</p>
            </div>
          </div>

          <div className="mt-8 flex items-center justify-between">
            {STEPS.map((step, i) => (
              <div key={step} className="flex flex-1 flex-col items-center text-center">
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold ${
                    i <= activeStep ? 'bg-brand-600 text-white' : 'bg-ink/10 text-ink/40'
                  }`}
                >
                  {i + 1}
                </div>
                <p className={`mt-2 text-xs font-medium ${i <= activeStep ? 'text-ink' : 'text-ink/40'}`}>{step}</p>
                {i < STEPS.length - 1 && (
                  <div className={`absolute mt-4 h-0.5 w-full ${i < activeStep ? 'bg-brand-600' : 'bg-ink/10'}`} style={{ display: 'none' }} />
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 border-t border-ink/10 pt-5">
            <h3 className="text-sm font-semibold text-ink">Items</h3>
            <div className="mt-3 space-y-2">
              {order.items.map((item) => (
                <div key={item.productId} className="flex justify-between text-sm text-ink/70">
                  <span>{item.name} x{item.quantity}</span>
                  <span>Rs. {(item.price * item.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>
            <p className="mt-4 text-sm text-ink/60">
              Delivering to: {order.address}, {order.city}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
