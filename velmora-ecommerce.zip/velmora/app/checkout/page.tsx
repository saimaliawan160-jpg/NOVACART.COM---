'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from '@/context/CartContext';
import * as store from '@/lib/store';
import { buildOrderMessage, buildWhatsAppLink } from '@/lib/whatsapp';
import { Order } from '@/lib/types';

const PAYMENT_METHODS: Order['paymentMethod'][] = ['COD', 'Easypaisa', 'JazzCash', 'Bank Transfer'];

export default function CheckoutPage() {
  const { cart, total, clear } = useCart();
  const router = useRouter();

  const [form, setForm] = useState({ name: '', phone: '', address: '', city: '' });
  const [payment, setPayment] = useState<Order['paymentMethod']>('COD');
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState('');

  const deliveryFee = total >= 3000 ? 0 : 200;
  const finalTotal = total + deliveryFee;

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (cart.length === 0) {
      setError('Your cart is empty.');
      return;
    }
    if (!form.name.trim() || !form.phone.trim() || !form.address.trim() || !form.city.trim()) {
      setError('Please fill in all fields.');
      return;
    }

    setPlacing(true);

    const orderId = store.generateOrderId();
    const order: Order = {
      id: orderId,
      customerName: form.name.trim(),
      phone: form.phone.trim(),
      address: form.address.trim(),
      city: form.city.trim(),
      paymentMethod: payment,
      items: cart,
      total: finalTotal,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };

    store.saveOrder(order);

    const message = buildOrderMessage({
      orderId,
      customerName: order.customerName,
      phone: order.phone,
      address: order.address,
      city: order.city,
      paymentMethod: order.paymentMethod,
      items: order.items,
      total: order.total,
    });
    const waLink = buildWhatsAppLink(message);

    clear();

    // Opens WhatsApp with the full order pre-filled, ready to send to the store's number.
    window.open(waLink, '_blank');

    router.push(`/track-order?id=${orderId}&placed=1`);
  }

  return (
    <div className="section-pad py-10">
      <h1 className="font-display text-3xl font-bold text-ink">Checkout</h1>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_360px]">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="text-sm font-semibold text-ink">Full Name</label>
            <input name="name" value={form.name} onChange={handleChange} className="input-field mt-1.5" placeholder="e.g. Ali Hassan" required />
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Phone Number</label>
            <input name="phone" value={form.phone} onChange={handleChange} className="input-field mt-1.5" placeholder="03XXXXXXXXX" required />
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Address</label>
            <input name="address" value={form.address} onChange={handleChange} className="input-field mt-1.5" placeholder="House #, Street, Area" required />
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">City</label>
            <input name="city" value={form.city} onChange={handleChange} className="input-field mt-1.5" placeholder="e.g. Lahore" required />
          </div>

          <div>
            <label className="text-sm font-semibold text-ink">Payment Method</label>
            <div className="mt-2 grid grid-cols-2 gap-3">
              {PAYMENT_METHODS.map((method) => (
                <button
                  type="button"
                  key={method}
                  onClick={() => setPayment(method)}
                  className={`rounded-xl border px-4 py-3 text-sm font-medium transition ${
                    payment === method ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-ink/10 text-ink/60 hover:border-ink/20'
                  }`}
                >
                  {method === 'COD' ? 'Cash on Delivery' : method}
                </button>
              ))}
            </div>
            {payment !== 'COD' && (
              <p className="mt-2 text-xs text-ink/50">
                You'll receive {payment} account details over WhatsApp to confirm your payment. See{' '}
                <a href="/payment-info" className="text-brand-600 underline">Payment Info</a> for details.
              </p>
            )}
          </div>

          {error && <p className="text-sm font-medium text-red-600">{error}</p>}

          <button type="submit" disabled={placing} className="btn-primary w-full">
            {placing ? 'Placing Order...' : 'Place Order & Confirm on WhatsApp'}
          </button>
          <p className="text-xs text-ink/40">
            Placing your order opens WhatsApp with your order details ready to send to our team for confirmation.
          </p>
        </form>

        <div className="h-fit rounded-2xl border border-ink/5 bg-white p-6 shadow-card">
          <h2 className="font-display text-lg font-bold text-ink">Order Summary</h2>
          <div className="mt-4 space-y-3">
            {cart.map((item) => (
              <div key={item.productId} className="flex justify-between text-sm">
                <span className="text-ink/70">{item.name} x{item.quantity}</span>
                <span className="font-medium text-ink">Rs. {(item.price * item.quantity).toLocaleString()}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-between border-t border-ink/10 pt-4 text-sm text-ink/60">
            <span>Delivery</span>
            <span>{deliveryFee === 0 ? 'Free' : `Rs. ${deliveryFee}`}</span>
          </div>
          <div className="mt-2 flex justify-between font-display text-base font-bold text-ink">
            <span>Total</span>
            <span>Rs. {finalTotal.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
