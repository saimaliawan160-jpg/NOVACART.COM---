export const metadata = {
  title: 'Payment Methods',
  description: 'Cash on Delivery, Easypaisa, JazzCash, and Bank Transfer payment instructions for Velmora orders.',
};

const methods = [
  {
    title: 'Cash on Delivery (COD)',
    icon: '💵',
    body: 'Pay in cash when your order is delivered to your doorstep. No advance payment needed. Our rider will confirm the order amount before handing over your package.',
  },
  {
    title: 'Easypaisa',
    icon: '📲',
    body: 'Send your payment to our Easypaisa account: 0337-4849767 (Account Title: Velmora Store). After sending payment, share the transaction screenshot on WhatsApp with your Order ID so we can confirm and dispatch your order.',
  },
  {
    title: 'JazzCash',
    icon: '📲',
    body: 'Send your payment to our JazzCash account: 0337-4849767 (Account Title: Velmora Store). After sending payment, share the transaction screenshot on WhatsApp with your Order ID so we can confirm and dispatch your order.',
  },
  {
    title: 'Bank Transfer',
    icon: '🏦',
    body: 'Bank: Meezan Bank | Account Title: Velmora Store | Account Number: 0123456789012 | IBAN: PK00MEZN0001234567890123. After transferring, send the receipt on WhatsApp along with your Order ID.',
  },
];

export default function PaymentInfoPage() {
  return (
    <div className="section-pad py-10">
      <h1 className="font-display text-3xl font-bold text-ink">Payment Methods</h1>
      <p className="mt-2 max-w-2xl text-sm text-ink/60">
        Choose whichever payment method is easiest for you at checkout. All online payments are confirmed manually
        over WhatsApp before your order ships, so there's no risk of double-charging.
      </p>

      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        {methods.map((m) => (
          <div key={m.title} className="rounded-2xl border border-ink/5 bg-white p-6 shadow-card">
            <div className="text-3xl">{m.icon}</div>
            <h2 className="mt-3 font-display text-lg font-bold text-ink">{m.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-ink/60">{m.body}</p>
          </div>
        ))}
      </div>

      <p className="mt-8 text-xs text-ink/40">
        Note: account numbers shown here are placeholders for this demo store — replace them with your real merchant
        account details before going live.
      </p>
    </div>
  );
}
