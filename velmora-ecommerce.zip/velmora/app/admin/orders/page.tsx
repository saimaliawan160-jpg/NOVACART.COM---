'use client';

import React, { useEffect, useState } from 'react';
import * as store from '@/lib/store';
import { Order, OrderStatus } from '@/lib/types';

const STATUSES: OrderStatus[] = ['Pending', 'Processing', 'Shipped', 'Delivered'];

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    setOrders(store.getOrders());
  }, []);

  function handleStatusChange(id: string, status: OrderStatus) {
    setOrders(store.updateOrderStatus(id, status));
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Orders</h1>
      <p className="mt-1 text-sm text-ink/50">{orders.length} total orders</p>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-ink/5 bg-white shadow-card">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-ink/5 text-xs uppercase tracking-wide text-ink/40">
            <tr>
              <th className="px-5 py-3">Order ID</th>
              <th className="px-5 py-3">Customer</th>
              <th className="px-5 py-3">Phone</th>
              <th className="px-5 py-3">Total</th>
              <th className="px-5 py-3">Status</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <React.Fragment key={o.id}>
                <tr className="border-b border-ink/5">
                  <td className="px-5 py-3 font-medium text-ink">{o.id}</td>
                  <td className="px-5 py-3">{o.customerName}</td>
                  <td className="px-5 py-3">{o.phone}</td>
                  <td className="px-5 py-3">Rs. {o.total.toLocaleString()}</td>
                  <td className="px-5 py-3">
                    <select
                      value={o.status}
                      onChange={(e) => handleStatusChange(o.id, e.target.value as OrderStatus)}
                      className="rounded-lg border border-ink/15 px-2 py-1 text-xs"
                    >
                      {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                  <td className="px-5 py-3">
                    <button
                      onClick={() => setExpanded(expanded === o.id ? null : o.id)}
                      className="text-xs font-semibold text-brand-600 hover:underline"
                    >
                      {expanded === o.id ? 'Hide' : 'Details'}
                    </button>
                  </td>
                </tr>
                {expanded === o.id && (
                  <tr className="border-b border-ink/5 bg-ink/[0.02]">
                    <td colSpan={6} className="px-5 py-4">
                      <p className="text-xs text-ink/50">Address: {o.address}, {o.city}</p>
                      <p className="mt-1 text-xs text-ink/50">Payment: {o.paymentMethod}</p>
                      <div className="mt-2 space-y-1">
                        {o.items.map((item) => (
                          <p key={item.productId} className="text-xs text-ink/70">
                            {item.name} x{item.quantity} — Rs. {(item.price * item.quantity).toLocaleString()}
                          </p>
                        ))}
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
        {orders.length === 0 && <p className="px-5 py-8 text-center text-sm text-ink/40">No orders yet.</p>}
      </div>
    </div>
  );
}
