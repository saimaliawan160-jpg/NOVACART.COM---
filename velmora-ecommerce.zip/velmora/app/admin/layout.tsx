'use client';

import { usePathname } from 'next/navigation';
import AdminGuard from '@/components/AdminGuard';
import AdminLayout from './AdminLayout';

export default function Layout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  if (pathname === '/admin/login') {
    return <>{children}</>;
  }

  return (
    <AdminGuard>
      <AdminLayout>{children}</AdminLayout>
    </AdminGuard>
  );
}
