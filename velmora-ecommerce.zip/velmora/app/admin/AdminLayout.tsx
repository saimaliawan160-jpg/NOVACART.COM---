'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import * as store from '@/lib/store';

const links = [
  { href: '/admin', label: 'Dashboard' },
  { href: '/admin/products', label: 'Products' },
  { href: '/admin/orders', label: 'Orders' },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const isLoginPage = pathname === '/admin/login';

  function handleLogout() {
    store.adminSignOut();
    router.push('/admin/login');
  }

  if (isLoginPage) return <>{children}</>;

  return (
    <div className="section-pad grid gap-8 py-10 lg:grid-cols-[220px_1fr]">
      <aside className="h-fit rounded-2xl border border-ink/5 bg-white p-4 shadow-card">
        <p className="px-2 text-xs font-semibold uppercase tracking-wide text-ink/40">Admin Panel</p>
        <nav className="mt-3 space-y-1">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`block rounded-lg px-3 py-2 text-sm font-medium ${
                pathname === l.href ? 'bg-brand-50 text-brand-700' : 'text-ink/60 hover:bg-ink/5'
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <button onClick={handleLogout} className="mt-4 w-full rounded-lg px-3 py-2 text-left text-sm font-medium text-red-600 hover:bg-red-50">
          Log Out
        </button>
      </aside>
      <div>{children}</div>
    </div>
  );
}
