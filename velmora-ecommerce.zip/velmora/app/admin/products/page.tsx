'use client';

import { useEffect, useState } from 'react';
import { PRODUCTS, CATEGORIES } from '@/lib/products';
import { Category, Product } from '@/lib/types';
import * as store from '@/lib/store';

const emptyForm = {
  name: '',
  category: CATEGORIES[0] as Category,
  price: '',
  description: '',
  image: '',
  stock: '20',
};

export default function AdminProductsPage() {
  const [customProducts, setCustomProducts] = useState<Product[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tab, setTab] = useState<'custom' | 'seed'>('custom');

  useEffect(() => {
    setCustomProducts(store.getCustomProducts<Product>());
  }, []);

  function resetForm() {
    setForm(emptyForm);
    setEditingId(null);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.price) return;

    const image = form.image.trim() || `https://picsum.photos/seed/${Date.now()}/600/600`;

    if (editingId) {
      const updated = customProducts.map((p) =>
        p.id === editingId
          ? {
              ...p,
              name: form.name,
              category: form.category,
              price: Number(form.price),
              description: form.description,
              images: [image],
              stock: Number(form.stock),
            }
          : p
      );
      store.saveCustomProducts(updated);
      setCustomProducts(updated);
    } else {
      const newProduct: Product = {
        id: `custom-${Date.now()}`,
        name: form.name,
        category: form.category,
        price: Number(form.price),
        description: form.description,
        images: [image],
        rating: 5,
        reviewCount: 0,
        reviews: [],
        stock: Number(form.stock),
      };
      const updated = [newProduct, ...customProducts];
      store.saveCustomProducts(updated);
      setCustomProducts(updated);
    }
    resetForm();
  }

  function handleEdit(p: Product) {
    setEditingId(p.id);
    setForm({
      name: p.name,
      category: p.category,
      price: String(p.price),
      description: p.description,
      image: p.images[0] || '',
      stock: String(p.stock),
    });
  }

  function handleDelete(id: string) {
    const updated = customProducts.filter((p) => p.id !== id);
    store.saveCustomProducts(updated);
    setCustomProducts(updated);
    if (editingId === id) resetForm();
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Products</h1>

      <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div>
          <div className="flex gap-2">
            <button
              onClick={() => setTab('custom')}
              className={`rounded-full px-4 py-1.5 text-sm font-medium ${tab === 'custom' ? 'bg-brand-600 text-white' : 'bg-ink/5 text-ink/60'}`}
            >
              Your Products ({customProducts.length})
            </button>
            <button
              onClick={() => setTab('seed')}
              className={`rounded-full px-4 py-1.5 text-sm font-medium ${tab === 'seed' ? 'bg-brand-600 text-white' : 'bg-ink/5 text-ink/60'}`}
            >
              Seed Catalog ({PRODUCTS.length})
            </button>
          </div>

          <div className="mt-4 overflow-x-auto rounded-2xl border border-ink/5 bg-white shadow-card">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-ink/5 text-xs uppercase tracking-wide text-ink/40">
                <tr>
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Price</th>
                  <th className="px-4 py-3">Stock</th>
                  {tab === 'custom' && <th className="px-4 py-3"></th>}
                </tr>
              </thead>
              <tbody>
                {(tab === 'custom' ? customProducts : PRODUCTS).map((p) => (
                  <tr key={p.id} className="border-b border-ink/5">
                    <td className="px-4 py-3 font-medium text-ink">{p.name}</td>
                    <td className="px-4 py-3 text-ink/60">{p.category}</td>
                    <td className="px-4 py-3">Rs. {p.price.toLocaleString()}</td>
                    <td className="px-4 py-3">{p.stock}</td>
                    {tab === 'custom' && (
                      <td className="px-4 py-3">
                        <button onClick={() => handleEdit(p)} className="mr-3 text-xs font-semibold text-brand-600 hover:underline">Edit</button>
                        <button onClick={() => handleDelete(p.id)} className="text-xs font-semibold text-red-600 hover:underline">Delete</button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            {tab === 'custom' && customProducts.length === 0 && (
              <p className="px-4 py-8 text-center text-sm text-ink/40">No custom products yet — add one using the form.</p>
            )}
          </div>
          {tab === 'seed' && (
            <p className="mt-3 text-xs text-ink/40">
              Seed catalog products are demo data defined in lib/products.ts. In production, move this catalog into
              Firestore using the functions in lib/firebase.ts so it can be edited here too.
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="h-fit rounded-2xl border border-ink/5 bg-white p-6 shadow-card">
          <h2 className="font-display text-lg font-bold text-ink">{editingId ? 'Edit Product' : 'Add Product'}</h2>
          <div className="mt-4 space-y-3">
            <input
              placeholder="Product name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="input-field"
              required
            />
            <select
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value as Category })}
              className="input-field"
            >
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <input
              type="number"
              placeholder="Price (Rs.)"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              className="input-field"
              required
            />
            <input
              type="number"
              placeholder="Stock quantity"
              value={form.stock}
              onChange={(e) => setForm({ ...form, stock: e.target.value })}
              className="input-field"
            />
            <input
              placeholder="Image URL (optional)"
              value={form.image}
              onChange={(e) => setForm({ ...form, image: e.target.value })}
              className="input-field"
            />
            <textarea
              placeholder="Description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="input-field min-h-[80px]"
            />
          </div>
          <button type="submit" className="btn-primary mt-4 w-full">{editingId ? 'Save Changes' : 'Add Product'}</button>
          {editingId && (
            <button type="button" onClick={resetForm} className="mt-2 w-full text-center text-sm text-ink/50 hover:text-ink">
              Cancel editing
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
