'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import * as store from '@/lib/store';

export default function AdminLoginPage() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (store.adminSignIn(password)) {
      router.push('/admin');
    } else {
      setError('Incorrect admin password.');
    }
  }

  return (
    <div className="section-pad flex min-h-[70vh] items-center justify-center py-10">
      <div className="w-full max-w-sm rounded-2xl border border-ink/5 bg-white p-8 shadow-card">
        <h1 className="font-display text-2xl font-bold text-ink">Admin Login</h1>
        <p className="mt-1 text-sm text-ink/50">Default demo password: admin123</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Admin password"
            className="input-field"
          />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button type="submit" className="btn-primary w-full">Log In</button>
        </form>
        <p className="mt-4 text-xs text-ink/40">
          Change ADMIN_PASSWORD in lib/store.ts before deploying to production.
        </p>
      </div>
    </div>
  );
}
