'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import * as store from '@/lib/store';
import { PRODUCTS } from '@/lib/products';
import { Order } from '@/lib/types';

export default function AdminDashboard() {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    setOrders(store.getOrders());
  }, []);

  const revenue = orders.reduce((s, o) => s + o.total, 0);
  const pending = orders.filter((o) => o.status === 'Pending').length;
  const customers = new Set(orders.map((o) => o.phone)).size;

  const stats = [
    { label: 'Total Orders', value: orders.length },
    { label: 'Revenue', value: `Rs. ${revenue.toLocaleString()}` },
    { label: 'Pending Orders', value: pending },
    { label: 'Unique Customers', value: customers },
    { label: 'Products Listed', value: PRODUCTS.length + store.getCustomProducts().length },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Dashboard</h1>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-ink/5 bg-white p-5 shadow-card">
            <p className="text-xs text-ink/50">{s.label}</p>
            <p className="mt-1 font-display text-xl font-bold text-ink">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-2xl border border-ink/5 bg-white p-6 shadow-card">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-ink">Recent Orders</h2>
          <Link href="/admin/orders" className="text-sm font-semibold text-brand-600 hover:underline">View all</Link>
        </div>
        <div className="mt-4 space-y-3">
          {orders.slice(0, 5).map((o) => (
            <div key={o.id} className="flex items-center justify-between border-b border-ink/5 pb-3 text-sm">
              <div>
                <p className="font-medium text-ink">{o.customerName}</p>
                <p className="text-ink/40">{o.id}</p>
              </div>
              <p className="text-ink/60">Rs. {o.total.toLocaleString()}</p>
              <span className="rounded-full bg-ink/5 px-3 py-1 text-xs font-medium text-ink/60">{o.status}</span>
            </div>
          ))}
          {orders.length === 0 && <p className="text-sm text-ink/40">No orders yet.</p>}
        </div>
      </div>
    </div>
  );
}
