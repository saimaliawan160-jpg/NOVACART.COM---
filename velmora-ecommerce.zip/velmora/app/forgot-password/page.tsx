'use client';

import { useState } from 'react';
import Link from 'next/link';
import * as store from '@/lib/store';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const result = store.resetPassword(email);
    if (!result.ok) {
      setError(result.error || 'Something went wrong.');
      setMessage('');
      return;
    }
    setError('');
    setMessage('If an account exists for this email, a reset link has been sent.');
  }

  return (
    <div className="section-pad flex min-h-[70vh] items-center justify-center py-10">
      <div className="w-full max-w-sm rounded-2xl border border-ink/5 bg-white p-8 shadow-card">
        <h1 className="font-display text-2xl font-bold text-ink">Reset your password</h1>
        <p className="mt-1 text-sm text-ink/50">Enter your email and we'll send you a reset link.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="input-field" />
          {error && <p className="text-sm text-red-600">{error}</p>}
          {message && <p className="text-sm text-brand-600">{message}</p>}
          <button type="submit" className="btn-primary w-full">Send Reset Link</button>
        </form>

        <p className="mt-4 text-center text-sm">
          <Link href="/login" className="text-brand-600 hover:underline">Back to login</Link>
        </p>
      </div>
    </div>
  );
}
