'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useCart } from '@/context/CartContext';

export default function CartPage() {
  const { cart, updateQty, removeItem, total } = useCart();

  if (cart.length === 0) {
    return (
      <div className="section-pad py-20 text-center">
        <p className="text-5xl">🛒</p>
        <h1 className="mt-4 font-display text-2xl font-bold text-ink">Your cart is empty</h1>
        <p className="mt-2 text-sm text-ink/50">Looks like you haven't added anything yet.</p>
        <Link href="/products" className="btn-primary mt-6 inline-block">Browse Products</Link>
      </div>
    );
  }

  return (
    <div className="section-pad py-10">
      <h1 className="font-display text-3xl font-bold text-ink">Your Cart</h1>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          {cart.map((item) => (
            <div key={item.productId} className="flex items-center gap-4 rounded-2xl border border-ink/5 bg-white p-4 shadow-card">
              <div className="relative h-20 w-20 overflow-hidden rounded-xl bg-ink/5">
                <Image src={item.image} alt={item.name} fill className="object-cover" />
              </div>
              <div className="flex-1">
                <p className="font-display text-sm font-semibold text-ink">{item.name}</p>
                <p className="mt-1 text-sm text-ink/50">Rs. {item.price.toLocaleString()}</p>
              </div>
              <div className="flex items-center rounded-full border border-ink/15">
                <button onClick={() => updateQty(item.productId, item.quantity - 1)} className="px-3 py-1.5">−</button>
                <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                <button onClick={() => updateQty(item.productId, item.quantity + 1)} className="px-3 py-1.5">+</button>
              </div>
              <p className="w-24 text-right font-display text-sm font-bold text-ink">
                Rs. {(item.price * item.quantity).toLocaleString()}
              </p>
              <button onClick={() => removeItem(item.productId)} aria-label="Remove" className="text-ink/40 hover:text-red-500">
                ✕
              </button>
            </div>
          ))}
        </div>

        <div className="h-fit rounded-2xl border border-ink/5 bg-white p-6 shadow-card">
          <h2 className="font-display text-lg font-bold text-ink">Order Summary</h2>
          <div className="mt-4 flex justify-between text-sm text-ink/60">
            <span>Subtotal</span>
            <span>Rs. {total.toLocaleString()}</span>
          </div>
          <div className="mt-2 flex justify-between text-sm text-ink/60">
            <span>Delivery</span>
            <span>{total >= 3000 ? 'Free' : 'Rs. 200'}</span>
          </div>
          <div className="mt-4 flex justify-between border-t border-ink/10 pt-4 font-display text-base font-bold text-ink">
            <span>Total</span>
            <span>Rs. {(total >= 3000 ? total : total + 200).toLocaleString()}</span>
          </div>
          <Link href="/checkout" className="btn-primary mt-6 block text-center">Proceed to Checkout</Link>
          <Link href="/products" className="mt-3 block text-center text-sm font-medium text-ink/50 hover:text-ink">
            Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  );
}
