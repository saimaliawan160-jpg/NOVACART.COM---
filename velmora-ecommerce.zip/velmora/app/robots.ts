import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: '*', allow: '/', disallow: ['/admin', '/cart', '/checkout'] },
    sitemap: 'https://www.velmora.com/sitemap.xml',
  };
}
