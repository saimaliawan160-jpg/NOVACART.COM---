'use client';

import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import ProductCard from '@/components/ProductCard';
import { PRODUCTS, CATEGORIES } from '@/lib/products';
import { Category, Product } from '@/lib/types';
import * as store from '@/lib/store';

function ProductsContent() {
  const searchParams = useSearchParams();
  const initialCategory = (searchParams.get('category') as Category) || 'All';
  const initialQuery = searchParams.get('q') || '';

  const [category, setCategory] = useState<Category | 'All'>(initialCategory);
  const [query, setQuery] = useState(initialQuery);
  const [sort, setSort] = useState('default');
  const [allProducts, setAllProducts] = useState<Product[]>(PRODUCTS);

  useEffect(() => {
    const custom = store.getCustomProducts<Product>();
    setAllProducts([...custom, ...PRODUCTS]);
  }, []);

  const filtered = useMemo(() => {
    let list = allProducts;
    if (category !== 'All') list = list.filter((p) => p.category === category);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }
    if (sort === 'price-asc') list = [...list].sort((a, b) => a.price - b.price);
    if (sort === 'price-desc') list = [...list].sort((a, b) => b.price - a.price);
    if (sort === 'rating') list = [...list].sort((a, b) => b.rating - a.rating);
    return list;
  }, [category, query, sort, allProducts]);

  return (
    <div className="section-pad py-10">
      <h1 className="font-display text-3xl font-bold text-ink">All Products</h1>
      <p className="mt-1 text-sm text-ink/50">{filtered.length} products found</p>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value as Category | 'All')}
          className="input-field w-auto"
        >
          <option value="All">All Categories</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>

        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products..."
          className="input-field w-auto flex-1 min-w-[200px]"
        />

        <select value={sort} onChange={(e) => setSort(e.target.value)} className="input-field w-auto">
          <option value="default">Sort: Featured</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
          <option value="rating">Top Rated</option>
        </select>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
      </div>

      {filtered.length === 0 && (
        <p className="mt-10 text-center text-ink/50">No products match your search. Try a different keyword or category.</p>
      )}
    </div>
  );
}

export default ProductsContent;
