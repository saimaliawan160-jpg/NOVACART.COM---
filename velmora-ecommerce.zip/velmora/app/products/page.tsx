import { Suspense } from 'react';
import ProductsContent from './ProductsContent';

export const metadata = {
  title: 'All Products',
  description: 'Browse smart gadgets, fashion accessories, beauty products, kitchen items, home decor, and trending finds at Velmora.',
};

export default function ProductsPage() {
  return (
    <Suspense fallback={<div className="section-pad py-20 text-center text-ink/40">Loading products...</div>}>
      <ProductsContent />
    </Suspense>
  );
}
