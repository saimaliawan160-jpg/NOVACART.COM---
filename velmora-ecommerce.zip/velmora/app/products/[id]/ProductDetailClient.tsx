'use client';

import { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Product } from '@/lib/types';
import StarRating from '@/components/StarRating';
import ReviewsSection from '@/components/ReviewsSection';
import { useCart } from '@/context/CartContext';

export default function ProductDetailClient({ product }: { product: Product }) {
  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const { addItem } = useCart();
  const router = useRouter();

  function handleAddToCart() {
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  }

  function handleBuyNow() {
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity,
    });
    router.push('/checkout');
  }

  return (
    <div className="grid gap-10 lg:grid-cols-2">
      <div>
        <div className="relative aspect-square overflow-hidden rounded-2xl bg-ink/5">
          <Image src={product.images[activeImage]} alt={product.name} fill className="object-cover" />
        </div>
        <div className="mt-3 flex gap-3">
          {product.images.map((img, i) => (
            <button
              key={i}
              onClick={() => setActiveImage(i)}
              className={`relative h-20 w-20 overflow-hidden rounded-xl border-2 ${
                i === activeImage ? 'border-brand-500' : 'border-transparent'
              }`}
            >
              <Image src={img} alt="" fill className="object-cover" />
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{product.category}</p>
        <h1 className="mt-1 font-display text-2xl font-bold text-ink sm:text-3xl">{product.name}</h1>
        <div className="mt-2 flex items-center gap-2">
          <StarRating rating={product.rating} />
          <span className="text-sm text-ink/50">{product.rating} ({product.reviewCount} reviews)</span>
        </div>

        <div className="mt-4 flex items-baseline gap-3">
          <span className="font-display text-3xl font-extrabold text-ink">Rs. {product.price.toLocaleString()}</span>
          {product.compareAtPrice && (
            <span className="text-base text-ink/40 line-through">Rs. {product.compareAtPrice.toLocaleString()}</span>
          )}
        </div>

        <p className="mt-4 text-sm leading-relaxed text-ink/70">{product.description}</p>

        <p className="mt-3 text-sm text-brand-700">{product.stock > 0 ? `In stock — ${product.stock} left` : 'Out of stock'}</p>

        <div className="mt-6 flex items-center gap-4">
          <div className="flex items-center rounded-full border border-ink/15">
            <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="px-4 py-2 text-lg">−</button>
            <span className="w-8 text-center text-sm font-semibold">{quantity}</span>
            <button onClick={() => setQuantity((q) => q + 1)} className="px-4 py-2 text-lg">+</button>
          </div>
          <button onClick={handleAddToCart} className="btn-secondary flex-1">
            {added ? 'Added to cart ✓' : 'Add to Cart'}
          </button>
        </div>
        <button onClick={handleBuyNow} className="btn-primary mt-3 w-full">Buy Now</button>

        <div className="mt-6 grid grid-cols-3 gap-3 rounded-xl bg-ink/5 p-4 text-center text-xs text-ink/60">
          <div>🚚<br />Fast Delivery</div>
          <div>💵<br />Cash on Delivery</div>
          <div>↩️<br />Easy Returns</div>
        </div>
      </div>

      <section className="lg:col-span-2">
        <h2 className="font-display text-xl font-bold text-ink">Customer Reviews</h2>
        <div className="mt-5">
          <ReviewsSection productId={product.id} baseReviews={product.reviews} />
        </div>
      </section>
    </div>
  );
}
