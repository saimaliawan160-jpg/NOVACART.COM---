'use client';

import { useEffect, useState } from 'react';
import { notFound } from 'next/navigation';
import { Product } from '@/lib/types';
import * as store from '@/lib/store';
import ProductDetailClient from './ProductDetailClient';

export default function CustomProductLookup({ id }: { id: string }) {
  const [product, setProduct] = useState<Product | null | undefined>(undefined);

  useEffect(() => {
    const custom = store.getCustomProducts<Product>();
    setProduct(custom.find((p) => p.id === id) || null);
  }, [id]);

  if (product === undefined) {
    return <div className="section-pad py-20 text-center text-ink/40">Loading product...</div>;
  }
  if (product === null) {
    notFound();
  }

  return (
    <div className="section-pad py-10">
      <ProductDetailClient product={product} />
    </div>
  );
}
