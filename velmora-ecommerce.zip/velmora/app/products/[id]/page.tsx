import { getProductById, PRODUCTS } from '@/lib/products';
import ProductDetailClient from './ProductDetailClient';
import CustomProductLookup from './CustomProductLookup';
import ProductCard from '@/components/ProductCard';

export function generateStaticParams() {
  return PRODUCTS.map((p) => ({ id: p.id }));
}

export function generateMetadata({ params }: { params: { id: string } }) {
  const product = getProductById(params.id);
  if (!product) return {};
  return {
    title: product.name,
    description: product.description,
    openGraph: { title: product.name, description: product.description, images: [product.images[0]] },
  };
}

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const product = getProductById(params.id);

  // Admin-added products live in localStorage (browser-only), so a server
  // lookup won't find them. Hand off to a client component that checks there.
  if (!product) {
    return <CustomProductLookup id={params.id} />;
  }

  const related = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  return (
    <div className="section-pad py-10">
      <ProductDetailClient product={product} />

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="font-display text-xl font-bold text-ink">You may also like</h2>
          <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  );
}
