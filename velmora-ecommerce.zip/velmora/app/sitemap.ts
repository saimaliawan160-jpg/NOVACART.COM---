import { MetadataRoute } from 'next';
import { PRODUCTS } from '@/lib/products';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = 'https://www.velmora.com';
  const staticPages = ['', '/products', '/track-order', '/payment-info', '/login', '/signup'].map((p) => ({
    url: `${base}${p}`,
    lastModified: new Date(),
  }));
  const productPages = PRODUCTS.map((p) => ({
    url: `${base}/products/${p.id}`,
    lastModified: new Date(),
  }));
  return [...staticPages, ...productPages];
}
