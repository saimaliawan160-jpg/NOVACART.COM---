import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { CartProvider } from '@/context/CartContext';
import { AuthProvider } from '@/context/AuthContext';

export const metadata: Metadata = {
  metadataBase: new URL('https://www.velmora.com'),
  title: {
    default: 'Velmora — Smart Gadgets, Beauty, Home & Trending Finds',
    template: '%s | Velmora',
  },
  description:
    'Shop smart gadgets, fashion accessories, beauty products, kitchen items, and home decor at Velmora. Fast delivery across Pakistan, Cash on Delivery available.',
  keywords: ['online shopping Pakistan', 'gadgets', 'beauty products', 'home decor', 'kitchen items', 'dropshipping store'],
  openGraph: {
    title: 'Velmora — Everyday finds, delivered to your door',
    description: 'Shop smart gadgets, beauty, kitchen, and home decor with fast delivery and Cash on Delivery.',
    type: 'website',
    siteName: 'Velmora',
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">
        <AuthProvider>
          <CartProvider>
            <Header />
            <main>{children}</main>
            <Footer />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
