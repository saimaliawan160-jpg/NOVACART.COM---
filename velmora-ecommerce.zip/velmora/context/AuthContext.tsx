'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import * as store from '@/lib/store';

interface Session {
  name: string;
  email: string;
}

interface AuthContextValue {
  session: Session | null;
  refresh: () => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);

  const refresh = () => setSession(store.getSession());

  useEffect(() => {
    refresh();
  }, []);

  const logout = () => {
    store.signOutUser();
    setSession(null);
  };

  return <AuthContext.Provider value={{ session, refresh, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
