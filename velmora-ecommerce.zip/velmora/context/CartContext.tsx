'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { CartItem } from '@/lib/types';
import * as store from '@/lib/store';

interface CartContextValue {
  cart: CartItem[];
  addItem: (item: CartItem) => void;
  updateQty: (productId: string, quantity: number) => void;
  removeItem: (productId: string) => void;
  clear: () => void;
  total: number;
  count: number;
}

const CartContext = createContext<CartContextValue | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);

  useEffect(() => {
    setCart(store.getCart());
  }, []);

  const addItem = (item: CartItem) => setCart(store.addToCart(item));
  const updateQty = (productId: string, quantity: number) => setCart(store.updateCartQuantity(productId, quantity));
  const removeItem = (productId: string) => setCart(store.removeFromCart(productId));
  const clear = () => {
    store.clearCart();
    setCart([]);
  };

  const total = store.cartTotal(cart);
  const count = cart.reduce((s, i) => s + i.quantity, 0);

  return (
    <CartContext.Provider value={{ cart, addItem, updateQty, removeItem, clear, total, count }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside CartProvider');
  return ctx;
}
