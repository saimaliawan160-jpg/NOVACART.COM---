'use client';

import { useState } from 'react';
import { Review } from '@/lib/types';
import StarRating from './StarRating';
import * as store from '@/lib/store';

export default function ReviewsSection({ productId, baseReviews }: { productId: string; baseReviews: Review[] }) {
  const [extra, setExtra] = useState<Review[]>(() => store.getUserReviews()[productId] || []);
  const [author, setAuthor] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const all = [...extra, ...baseReviews];

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!author.trim() || !comment.trim()) return;
    const review: Review = {
      id: `user-${Date.now()}`,
      author: author.trim(),
      rating,
      comment: comment.trim(),
      date: new Date().toISOString().slice(0, 10),
    };
    const updated = store.addUserReview(productId, review);
    setExtra(updated);
    setAuthor('');
    setComment('');
    setRating(5);
    setSubmitted(true);
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_320px]">
      <div className="space-y-6">
        {all.map((r) => (
          <div key={r.id} className="border-b border-ink/5 pb-5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-ink">{r.author}</span>
              <span className="text-xs text-ink/40">{r.date}</span>
            </div>
            <div className="mt-1"><StarRating rating={r.rating} size={14} /></div>
            <p className="mt-2 text-sm text-ink/70">{r.comment}</p>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="h-fit rounded-2xl border border-ink/5 bg-white p-5 shadow-card">
        <h4 className="font-display text-sm font-bold text-ink">Write a review</h4>
        {submitted && <p className="mt-2 text-xs font-medium text-brand-600">Thanks! Your review has been posted.</p>}
        <div className="mt-3 flex gap-1">
          {[1, 2, 3, 4, 5].map((s) => (
            <button type="button" key={s} onClick={() => setRating(s)} aria-label={`${s} stars`}>
              <StarRating rating={rating >= s ? s : 0} size={18} />
            </button>
          ))}
        </div>
        <input
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          placeholder="Your name"
          className="input-field mt-3"
          required
        />
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Share your experience with this product"
          className="input-field mt-3 min-h-[90px]"
          required
        />
        <button type="submit" className="btn-primary mt-3 w-full">Submit Review</button>
      </form>
    </div>
  );
}
