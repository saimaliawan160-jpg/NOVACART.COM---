export default function StarRating({ rating, size = 16 }: { rating: number; size?: number }) {
  const stars = [1, 2, 3, 4, 5];
  return (
    <span className="inline-flex items-center gap-0.5" aria-label={`${rating} out of 5 stars`}>
      {stars.map((s) => {
        const filled = rating >= s;
        const half = !filled && rating >= s - 0.5;
        return (
          <svg
            key={s}
            width={size}
            height={size}
            viewBox="0 0 20 20"
            fill={filled ? '#f5a524' : half ? 'url(#half)' : '#e2e8f0'}
          >
            {half && (
              <defs>
                <linearGradient id="half">
                  <stop offset="50%" stopColor="#f5a524" />
                  <stop offset="50%" stopColor="#e2e8f0" />
                </linearGradient>
              </defs>
            )}
            <path d="M10 1.5l2.59 5.25 5.79.84-4.19 4.08.99 5.76L10 14.9l-5.18 2.53.99-5.76-4.19-4.08 5.79-.84z" />
          </svg>
        );
      })}
    </span>
  );
}
