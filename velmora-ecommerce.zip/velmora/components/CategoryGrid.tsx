import Link from 'next/link';
import { CATEGORIES } from '@/lib/products';

const icons: Record<string, string> = {
  'Smart Gadgets': '📱',
  'Fashion Accessories': '👜',
  'Beauty Products': '💄',
  'Kitchen Items': '🍳',
  'Home Decor': '🏠',
  'Trending Products': '🔥',
};

export default function CategoryGrid() {
  return (
    <section className="section-pad py-14">
      <h2 className="font-display text-2xl font-bold text-ink">Shop by Category</h2>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {CATEGORIES.map((c) => (
          <Link
            key={c}
            href={`/products?category=${encodeURIComponent(c)}`}
            className="flex flex-col items-center gap-2 rounded-2xl border border-ink/5 bg-white p-5 text-center shadow-card transition hover:-translate-y-1 hover:border-brand-200"
          >
            <span className="text-3xl">{icons[c]}</span>
            <span className="text-sm font-semibold text-ink">{c}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}
