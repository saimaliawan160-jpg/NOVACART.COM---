'use client';

import { useEffect, useState, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import * as store from '@/lib/store';

export default function AdminGuard({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (!store.isAdmin()) {
      router.replace('/admin/login');
    } else {
      setChecked(true);
    }
  }, [router]);

  if (!checked) return <div className="section-pad py-20 text-center text-ink/40">Checking admin access...</div>;
  return <>{children}</>;
}
