import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-ink/5 bg-ink text-white/80">
      <div className="section-pad grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 font-display text-lg font-extrabold text-white">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-ocean-600 text-sm">V</span>
            Velmora
          </div>
          <p className="mt-3 text-sm text-white/60">
            Everyday essentials and trending finds, picked for quality and shipped fast across Pakistan.
          </p>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold text-white">Shop</h4>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link href="/products" className="hover:text-white">All Products</Link></li>
            <li><Link href="/products?category=Trending%20Products" className="hover:text-white">Trending</Link></li>
            <li><Link href="/track-order" className="hover:text-white">Track Order</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold text-white">Help</h4>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link href="/payment-info" className="hover:text-white">Payment Methods</Link></li>
            <li><Link href="/login" className="hover:text-white">My Account</Link></li>
            <li><Link href="/admin/login" className="hover:text-white">Admin</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold text-white">Contact</h4>
          <p className="mt-3 text-sm text-white/60">Orders are confirmed over WhatsApp for a fast, personal checkout experience.</p>
        </div>
      </div>
      <div className="section-pad border-t border-white/10 py-5 text-center text-xs text-white/40">
        © {new Date().getFullYear()} Velmora. All rights reserved.
      </div>
    </footer>
  );
}
