import Link from 'next/link';

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-white to-ocean-50">
      <div className="section-pad grid items-center gap-10 py-16 lg:grid-cols-2 lg:py-24">
        <div>
          <span className="inline-block rounded-full bg-brand-100 px-3 py-1 text-xs font-semibold text-brand-700">
            Free delivery on orders over Rs. 3,000
          </span>
          <h1 className="mt-5 font-display text-4xl font-extrabold leading-tight text-ink sm:text-5xl">
            Everyday finds, <span className="text-brand-600">delivered</span> to your door.
          </h1>
          <p className="mt-4 max-w-md text-base text-ink/60">
            Smart gadgets, beauty essentials, kitchen tools, and home decor — curated and quality-checked, with easy Cash on Delivery.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/products" className="btn-primary">Shop Now</Link>
            <Link href="/products?category=Trending%20Products" className="btn-secondary">See What's Trending</Link>
          </div>
        </div>
        <div className="relative">
          <div className="grid grid-cols-2 gap-4">
            <img src="https://picsum.photos/seed/heroA/500/600" alt="" className="h-full w-full rounded-2xl object-cover shadow-card" />
            <div className="flex flex-col gap-4">
              <img src="https://picsum.photos/seed/heroB/500/280" alt="" className="rounded-2xl object-cover shadow-card" />
              <img src="https://picsum.photos/seed/heroC/500/280" alt="" className="rounded-2xl object-cover shadow-card" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
