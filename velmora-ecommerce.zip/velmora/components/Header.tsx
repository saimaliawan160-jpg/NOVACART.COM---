'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { CATEGORIES } from '@/lib/products';

export default function Header() {
  const { count } = useCart();
  const { session, logout } = useAuth();
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim()) router.push(`/products?q=${encodeURIComponent(query.trim())}`);
  }

  return (
    <header className="sticky top-0 z-50 border-b border-ink/5 bg-white/95 backdrop-blur">
      <div className="section-pad flex h-16 items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2 font-display text-xl font-extrabold text-ink">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-ocean-600 text-sm text-white">V</span>
          Velmora
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-ink/70 lg:flex">
          <Link href="/products" className="hover:text-brand-600">All Products</Link>
          {CATEGORIES.slice(0, 4).map((c) => (
            <Link key={c} href={`/products?category=${encodeURIComponent(c)}`} className="hover:text-brand-600">
              {c}
            </Link>
          ))}
          <Link href="/track-order" className="hover:text-brand-600">Track Order</Link>
        </nav>

        <form onSubmit={handleSearch} className="hidden max-w-xs flex-1 md:flex">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products..."
            className="w-full rounded-full border border-ink/10 bg-ink/5 px-4 py-2 text-sm outline-none focus:border-brand-400 focus:bg-white"
          />
        </form>

        <div className="flex items-center gap-3">
          {session ? (
            <div className="hidden items-center gap-2 text-sm sm:flex">
              <span className="text-ink/70">Hi, {session.name.split(' ')[0]}</span>
              <button onClick={logout} className="font-medium text-brand-600 hover:underline">Logout</button>
            </div>
          ) : (
            <Link href="/login" className="hidden text-sm font-medium text-ink/70 hover:text-brand-600 sm:block">
              Login
            </Link>
          )}
          <Link href="/cart" className="relative flex h-10 w-10 items-center justify-center rounded-full bg-ink/5 hover:bg-ink/10">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
            </svg>
            {count > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-ocean-600 text-[10px] font-bold text-white">
                {count}
              </span>
            )}
          </Link>
          <button className="lg:hidden" onClick={() => setMenuOpen((v) => !v)} aria-label="Menu">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 6h18M3 12h18M3 18h18" />
            </svg>
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="border-t border-ink/5 px-5 py-4 lg:hidden">
          <form onSubmit={handleSearch} className="mb-3 flex">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products..."
              className="input-field"
            />
          </form>
          <div className="flex flex-col gap-3 text-sm font-medium text-ink/70">
            <Link href="/products" onClick={() => setMenuOpen(false)}>All Products</Link>
            {CATEGORIES.map((c) => (
              <Link key={c} href={`/products?category=${encodeURIComponent(c)}`} onClick={() => setMenuOpen(false)}>
                {c}
              </Link>
            ))}
            <Link href="/track-order" onClick={() => setMenuOpen(false)}>Track Order</Link>
            <Link href="/payment-info" onClick={() => setMenuOpen(false)}>Payment Info</Link>
            {!session && <Link href="/login" onClick={() => setMenuOpen(false)}>Login</Link>}
          </div>
        </div>
      )}
    </header>
  );
}
