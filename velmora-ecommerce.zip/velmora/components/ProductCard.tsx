import Link from 'next/link';
import Image from 'next/image';
import { Product } from '@/lib/types';
import StarRating from './StarRating';

export default function ProductCard({ product }: { product: Product }) {
  const discount = product.compareAtPrice
    ? Math.round(100 - (product.price / product.compareAtPrice) * 100)
    : null;

  return (
    <Link
      href={`/products/${product.id}`}
      className="group block overflow-hidden rounded-2xl border border-ink/5 bg-white shadow-card transition hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="relative aspect-square overflow-hidden bg-ink/5">
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover transition duration-300 group-hover:scale-105"
        />
        {discount && (
          <span className="absolute left-3 top-3 rounded-full bg-ocean-600 px-2.5 py-1 text-xs font-semibold text-white">
            -{discount}%
          </span>
        )}
      </div>
      <div className="p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-brand-600">{product.category}</p>
        <h3 className="mt-1 line-clamp-2 font-display text-sm font-semibold text-ink">{product.name}</h3>
        <div className="mt-2 flex items-center gap-1.5">
          <StarRating rating={product.rating} size={14} />
          <span className="text-xs text-ink/50">({product.reviewCount})</span>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="font-display text-base font-bold text-ink">Rs. {product.price.toLocaleString()}</span>
          {product.compareAtPrice && (
            <span className="text-xs text-ink/40 line-through">Rs. {product.compareAtPrice.toLocaleString()}</span>
          )}
        </div>
      </div>
    </Link>
  );
}
