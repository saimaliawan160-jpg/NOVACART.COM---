/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eefcf5',
          100: '#d6f7e6',
          200: '#aeedcd',
          300: '#78dcae',
          400: '#42c48c',
          500: '#1fa873',
          600: '#15875c',
          700: '#136b4b',
          800: '#13543d',
          900: '#114633',
        },
        ocean: {
          50: '#eef7ff',
          100: '#d9edff',
          200: '#bbdfff',
          300: '#8cc9ff',
          400: '#56abff',
          500: '#2f8af0',
          600: '#1f6cd1',
          700: '#1c57aa',
          800: '#1c4a89',
          900: '#1c3f71',
        },
        ink: '#0f172a',
      },
      fontFamily: {
        display: ['Sora', 'ui-sans-serif', 'system-ui'],
        body: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(15,23,42,0.06), 0 8px 24px -8px rgba(15,23,42,0.12)',
      },
    },
  },
  plugins: [],
};
