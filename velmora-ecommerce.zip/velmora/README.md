# Velmora — Full-Stack Dropshipping Store

A complete, working Shopify-style storefront built with Next.js 14 (App Router) + Tailwind CSS.
Runs immediately with **zero backend setup** (cart, orders, accounts, and the admin panel use
localStorage), and includes a ready-to-activate Firebase upgrade path for production use.

## What's included

- Home page, 53-product catalog across 6 categories, product detail pages with image gallery,
  star ratings, and a working reviews form
- Cart with quantity updates, checkout form, 4 payment methods (COD, Easypaisa, JazzCash, Bank Transfer)
- **Automatic WhatsApp order message** — placing an order opens WhatsApp with the full order
  pre-filled, ready to send to your number
- Order tracking by Order ID with a visual status timeline
- Customer login / signup / forgot password
- Admin panel: dashboard stats, add/edit/delete products, manage all orders, update order status
- SEO: per-page metadata, sitemap.xml, robots.txt, clean URLs
- Firebase-ready code (`lib/firebase.ts`) for Auth, Firestore, and Storage — swap in when you're ready

## 1. Run it locally

```bash
npm install
cp .env.local.example .env.local
# open .env.local and set your WhatsApp number (country code, no + or spaces)
npm run dev
```

Open http://localhost:3000

**Admin panel:** go to `/admin/login` — default password is `admin123`.
Change it in `lib/store.ts` (the `ADMIN_PASSWORD` constant) before going live.

## 2. How the WhatsApp ordering works

When a customer fills out the checkout form and clicks **Place Order**:

1. The order is saved (so it shows up in Order Tracking and the Admin → Orders panel)
2. A professionally formatted message is built (see `lib/whatsapp.ts`):

```
🛍️ New Order Received

Order ID: VLM4F2A1B
Name: Ali Hassan
Phone: 03001234567
Address: House 12, Street 4, DHA, Lahore
Payment Method: COD

Products:
  • Wireless Earbuds Pro x1 — Rs. 3,499

Total: Rs. 3,699
Status: Pending
```

3. WhatsApp opens in a new tab with this message pre-filled, addressed to your number, via a
   `wa.me` link — the customer just taps Send to confirm the order with you.

This is the standard, reliable way to do "auto-send to WhatsApp" without paying for the official
WhatsApp Business API. If you later want messages sent **without** the customer tapping Send
(fully server-side), you'd need the paid WhatsApp Cloud API — ask your developer to wire that into
the `handleSubmit` function in `app/checkout/page.tsx` in place of `window.open`.

To change the receiving number, edit `NEXT_PUBLIC_WHATSAPP_NUMBER` in `.env.local`.

## 3. Moving from localStorage to Firebase (recommended before launch)

The site works fully without Firebase, but localStorage is per-browser — an order placed on a
customer's phone won't show up in your admin panel on your laptop. For a real store, connect Firebase:

1. Go to https://console.firebase.google.com → **Add project**
2. In your project, enable:
   - **Authentication** → Sign-in method → Email/Password
   - **Firestore Database** → Create database (start in production mode)
   - **Storage** → Get started
3. Go to Project Settings → General → scroll to "Your apps" → Add a **Web app**
4. Copy the config values into `.env.local`:
   ```
   NEXT_PUBLIC_FIREBASE_API_KEY=...
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=...
   NEXT_PUBLIC_FIREBASE_PROJECT_ID=...
   NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=...
   NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=...
   NEXT_PUBLIC_FIREBASE_APP_ID=...
   ```
5. `lib/firebase.ts` already exports ready-made functions: `fsGetProducts`, `fsAddProduct`,
   `fsCreateOrder`, `fsGetOrders`, `fsUpdateOrderStatus`, `authSignUp`, `authSignIn`, `authResetPassword`,
   `storageUploadImage`, etc. Replace the matching calls in `lib/store.ts` and the admin pages with
   these — the function signatures are intentionally close so the swap is mostly mechanical.
6. Recommended Firestore security rules to start with (tighten further before launch):
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /products/{productId} {
         allow read: if true;
         allow write: if request.auth != null; // restrict to admin uid in production
       }
       match /orders/{orderId} {
         allow create: if true;
         allow read, update: if request.auth != null;
       }
     }
   }
   ```

## 4. Deployment guide (Vercel — recommended for Next.js)

1. Push this project to a GitHub repository
2. Go to https://vercel.com → **New Project** → import your repo
3. Add your `.env.local` values under Project Settings → Environment Variables
4. Click **Deploy** — Vercel builds and hosts it automatically, with HTTPS included for free

### Buying a domain

1. Buy a domain on **Namecheap** or **GoDaddy** (e.g. velmora.com)
2. In Vercel: Project → Settings → Domains → Add your domain
3. Vercel will show you DNS records (usually an `A` record or `CNAME`) to add
4. In Namecheap/GoDaddy → DNS settings for your domain → add those exact records
5. Wait 10 minutes–24 hours for DNS to propagate — Vercel issues a free SSL certificate
   automatically once it's verified, so your site will be on `https://` with no extra steps

### Alternative: Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy
```
Then connect your custom domain under Firebase Console → Hosting → Add custom domain.

## 5. Project structure

```
velmora/
├── app/
│   ├── page.tsx                 Home page
│   ├── products/                Listing + [id] detail pages
│   ├── cart/                    Cart page
│   ├── checkout/                Checkout + WhatsApp order trigger
│   ├── track-order/             Order tracking
│   ├── payment-info/            COD / Easypaisa / JazzCash / Bank info
│   ├── login/ signup/ forgot-password/
│   ├── admin/                   Admin dashboard, products, orders (password protected)
│   ├── robots.ts, sitemap.ts    SEO
│   └── layout.tsx, globals.css
├── components/                  Header, Footer, ProductCard, StarRating, Reviews, etc.
├── context/                     CartContext, AuthContext
├── lib/
│   ├── types.ts                 Shared TypeScript types
│   ├── products.ts              53-product seed catalog
│   ├── store.ts                 localStorage data layer (cart/orders/auth/admin)
│   ├── firebase.ts              Firebase Auth/Firestore/Storage functions (optional upgrade)
│   └── whatsapp.ts              Order message + wa.me link builder
└── .env.local.example
```

## 6. Things to change before going live

- [ ] Set your real WhatsApp number in `.env.local`
- [ ] Change the admin password in `lib/store.ts`
- [ ] Replace the placeholder Easypaisa/JazzCash/bank details in `app/payment-info/page.tsx`
- [ ] Replace placeholder product images (`picsum.photos`) with real product photos
- [ ] Connect Firebase (section 3) so orders/accounts persist across devices
- [ ] Update brand name/colors in `tailwind.config.js` and `components/Header.tsx` if desired
